# VajraClaw Enterprise (Air-Gapped Edition) - SECURITY & EULA

**CRITICAL DEPLOYMENT NOTICE**
This is the **Enterprise 100% Air-Gapped Edition** of the VajraClaw SDK.

Unlike the Hacker or Startup tiers, this binary has been compiled with **all external network telemetry and validation modules physically removed at the C/Rust level**. 

## Validation Mechanism
This edition relies entirely on localized RSA cryptographic signature validation.
1. When initializing the SDK in your secure intranet, provide the `License Key` issued by Gumroad.
2. The core `.dll` or `.so` binary will decrypt the key using its baked-in public key to authorize up to **30 Concurrent Agents per Machine** across **15 Machine UUIDs**.
3. **ZERO outbound HTTP requests** will ever be made to `api.dr-os.io`. It is safe for extreme security environments.

## EULA Terms
1. **No Decompilation:** Any attempt to reverse engineer the binary to bypass the 30-agent limit will permanently void your enterprise license and SLA support without refund.
2. **Key Security:** You are solely responsible for the physical security of your Gumroad-issued License Key. If the key is leaked, our revocation lists cannot reach your air-gapped instances; you must manually deploy updated rule constraints.
